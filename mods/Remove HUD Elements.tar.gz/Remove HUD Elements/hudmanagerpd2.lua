local _throwaway_lambda =
function(source, ...)
	return
end

local _remove_functions = {
	"set_control_info",
	"sync_start_assault",
	"sync_end_assault",
	"sync_assault_number",
	"show_casing",
	"hide_casing",
	"sync_set_assault_mode",
	"set_buff_enabled",
	"feed_point_of_no_return_timer",
	"show_point_of_no_return_timer",
	"hide_point_of_no_return_timer"
}

local _remove_functions2 = {
	"_create_heist_timer",
	"feed_heist_time",
	"modify_heist_time",
	"_create_objective",
	"activate_objective",
	"update_amount_objective",
	"remind_objective",
	"complete_objective"
}
if not BAI then
	for _,v in pairs(_remove_functions) do
		HUDManager[v] = _throwaway_lambda
	end
end

for _,v in pairs(_remove_functions2) do
	HUDManager[v] = _throwaway_lambda
end