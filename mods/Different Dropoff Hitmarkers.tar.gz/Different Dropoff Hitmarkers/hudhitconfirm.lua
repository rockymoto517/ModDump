Hooks:PostHook(HUDHitConfirm, "init", "extra_hitmarker_init",
function(self)
    if self._hud_panel:child("low_damage_confirm") then
        self._hud_panel:remove(self._hud_panel:child("low_damage_confirm"))
    end

    if self._hud_panel:child("low_crit_confirm") then
        self._hud_panel:remove(self._hud_panel:child("low_crit_confirm"))
    end

    self._low_damage_confirm = self._hud_panel:bitmap({
        texture = "guis/textures/pd2/hitconfirm",
        name = "low_damage_confirm",
        halign = "center",
        visible = false,
        layer = 1,
        blend_mode = "add",
        valign = "center",
        color = Color.red
    })

    self._low_crit_confirm = self._hud_panel:bitmap({
        texture = "guis/textures/pd2/hitconfirm_crit",
        name = "low_crit_confirm",
        halign = "center",
        visible = false,
        layer = 1,
        blend_mode = "add",
        valign = "center",
        color = Color.red
    })

    self._low_damage_confirm:set_center(self._hud_panel:w() / 2, self._hud_panel:h() / 2)
    self._low_crit_confirm:set_center(self._hud_panel:w() / 2, self._hud_panel:h() / 2)
end)

function HUDHitConfirm:on_hit_confirmed(damage_scale)
    self._hit_confirm:stop()
    self._low_damage_confirm:stop()

    if not damage_scale or damage_scale == 1 then
        self._hit_confirm:animate(callback(self, self, "_animate_show"), callback(self, self, "show_done"), 0.25, damage_scale)
    elseif damage_scale ~= 1 then
        self._low_damage_confirm:animate(callback(self, self, "_animate_show"), callback(self, self, "show_done"), 0.25, damage_scale)
    end
end

function HUDHitConfirm:on_headshot_confirmed(damage_scale)
    self._hit_confirm:stop()
    self._low_damage_confirm:stop()

    if not damage_scale or damage_scale == 1 then
        self._hit_confirm:animate(callback(self, self, "_animate_show"), callback(self, self, "show_done"), 0.25, damage_scale)
    elseif damage_scale ~= 1 then
        self._low_damage_confirm:animate(callback(self, self, "_animate_show"), callback(self, self, "show_done"), 0.25, damage_scale)
    end
end

function HUDHitConfirm:on_crit_confirmed(damage_scale)
    self._crit_confirm:stop()
    self._low_crit_confirm:stop()

    if not damage_scale or damage_scale == 1 then
        self._crit_confirm:animate(callback(self, self, "_animate_show"), callback(self, self, "show_done"), 0.25, damage_scale)
    elseif damage_scale ~= 1 then
        self._low_crit_confirm:animate(callback(self, self, "_animate_show"), callback(self, self, "show_done"), 0.25, damage_scale)
    end
end

function HUDHitConfirm:_animate_show(hint_confirm, done_cb, seconds, damage_scale)
	hint_confirm:set_visible(true)
	hint_confirm:set_alpha(1)

	local cx, cy = hint_confirm:center()

	hint_confirm:set_size(hint_confirm:texture_width(), hint_confirm:texture_height())
	hint_confirm:set_center(cx, cy)

	local t = seconds

	while t > 0 do
		local dt = coroutine.yield()
		t = t - dt

		hint_confirm:set_alpha(t / seconds)
	end

    hint_confirm:set_alpha(0)
	hint_confirm:set_visible(false)
	done_cb()
end