if RequiredScript == "lib/managers/mission/elementspawnenemydummy" then
	_old_produce = ElementSpawnEnemyDummy.produce
	function ElementSpawnEnemyDummy:produce(params)
		local unit = _old_produce(self, params)

		unit:set_visible(false)

		if unit:inventory():get_weapon() then
			unit:inventory():get_weapon():set_visible(false)
		end

		if unit:inventory():shield_unit() then
			unit:inventory():shield_unit():set_visible(false)
		end
	end

elseif RequiredScript == "lib/units/enemies/cop/copmovement" then
	function CopMovement:anim_clbk_set_visibility(unit, state)
		self._unit:set_visible(false)
	end
end