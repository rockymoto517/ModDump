BeardLib:AddUpdater(
    "textures_refresh",
    function(t, dt)
        managers.viewport._render_settings_change_map = {resolution = RenderSettings.resolution}

        if BeardLib._updaters.textures_refresh then
            BeardLib:RemoveUpdater("textures_refresh")
        end
    end,
    true
)