if managers.chat then
    managers.chat:send_message(1, managers.network.account:username() or "AverageDeathSentencePlayer42069", "objective???")
end