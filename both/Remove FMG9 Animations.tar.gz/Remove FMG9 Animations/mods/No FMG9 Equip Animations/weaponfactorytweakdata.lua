local old_init = WeaponFactoryTweakData.init

function WeaponFactoryTweakData:init(tweak_data)
    old_init(self, tweak_data)
	self.parts.wpn_fps_smg_fmg9_body = {
		texture_bundle_folder = "lawp",
		type = "reciever",
		a_obj = "a_upper",
		dlc = "lawp",
		name_id = "bm_wp_fmg9_body",
		unit = "units/pd2_dlc_lawp/weapons/wpn_fps_smg_fmg9_pts/wpn_fps_smg_fmg9_body",
		stats = {
			value = 1
		},
		adds = {
			"wpn_fps_smg_fmg9_o_sight",
			"wpn_fps_smg_fmg9_b_dummy"
		}
	}
	self.parts.wpn_fps_smg_fmg9_grip = {
		texture_bundle_folder = "lawp",
		dlc = "lawp",
		type = "grip",
		name_id = "bm_wp_fmg9_grip",
		unit = "units/pd2_dlc_lawp/weapons/wpn_fps_smg_fmg9_pts/wpn_fps_smg_fmg9_grip",
		a_obj = "a_grip",
		stats = {
			value = 1
		},
		animations = {
			reload = "reload",
			reload_not_empty = "reload_not_empty"
		}
	}
	self.parts.wpn_fps_smg_fmg9_stock = {
		texture_bundle_folder = "lawp",
		dlc = "lawp",
		type = "stock",
		name_id = "bm_wp_fmg9_stock",
		unit = "units/pd2_dlc_lawp/weapons/wpn_fps_smg_fmg9_pts/wpn_fps_smg_fmg9_stock",
		a_obj = "a_stock",
		stats = {
			value = 1
		}
	}
	self.parts.wpn_fps_smg_fmg9_stock_padded = {
		texture_bundle_folder = "lawp",
		type = "stock",
		a_obj = "a_stock",
		dlc = "lawp",
		name_id = "bm_wp_fmg9_stock_padded",
		unit = "units/pd2_dlc_lawp/weapons/wpn_fps_smg_fmg9_pts/wpn_fps_smg_fmg9_stock_padded",
		pcs = {
			10,
			20,
			30,
			40
		},
		stats = {
			value = 1,
			recoil = 2,
			spread = 2,
			concealment = -2
		}
	}
	self.parts.wpn_fps_smg_fmg9_body_conversion = {
		texture_bundle_folder = "lawp",
		dlc = "lawp",
		type = "reciever",
		name_id = "bm_wp_fmg9_body",
		unit = "units/pd2_dlc_lawp/weapons/wpn_fps_smg_fmg9_pts/wpn_fps_smg_fmg9_body_conversion",
		a_obj = "a_upper",
		stats = {
			value = 1
		}
	}	
end